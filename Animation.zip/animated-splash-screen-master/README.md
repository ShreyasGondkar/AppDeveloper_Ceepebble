# animated-splash-screen
Jetpack Compose animated splash screen

**Animated Splash Screen**

<a href="https://github.com/raheemadamboev/animated-splash-screen/blob/master/app-debug.apk">Demo app</a>

**Screenshots:**

<img src="https://github.com/raheemadamboev/animated-splash-screen/blob/master/IMG_20211003_180550_264.gif" alt="Italian Trulli" width="200" height="400">

**Tech stack:**

- Jetpack Compose
- Animated Splash Screen
